import React from 'react'
import Button from './Button'
import LableToShow from './LableToShow'

export default function Page() {
    return (
        <div>
            <Button />
            <div>
                <LableToShow />
            </div>
        </div>
    )
}
