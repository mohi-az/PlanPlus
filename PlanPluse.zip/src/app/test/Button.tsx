"use client"
import { useParams, useRouter, useSearchParams } from 'next/navigation'
import React, { useState } from 'react'

export default function Button() {
    const s = useSearchParams();
    const router = useRouter();
    const [counter, setCounter] = useState(0);
    const onClickHandler = () => {
        setCounter(Pre => Pre + 1)
        const l = new URLSearchParams(s.toString())
        l.set("counter", counter.toString())
        router.replace(`?${l.toString()}`)
    }
    return (
        <div><button className='btn btn-square' onClick={onClickHandler}> Click to add
        </button></div>
    )
}
