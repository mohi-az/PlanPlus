"use client"
import { useSearchParams } from 'next/navigation'
import React from 'react'

export default function LableToShow() {
    const s = useSearchParams();
    const value = s.get("counter");
  return (
    <div>The number is {value}</div>
  )
}
